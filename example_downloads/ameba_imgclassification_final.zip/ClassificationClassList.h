#ifndef __CLASSIFICATIONCLASSLIST_H__
#define __CLASSIFICATIONCLASSLIST_H__

struct ClassificationDetectionItem {
    uint8_t index;
    const char* imgclassName;
    uint8_t filter;
};

ClassificationDetectionItem imgclassItemList[5] = {
    {0, "chunxiang", 1},
    {1, "minge", 1},
    {2, "changtiao", 1},
    {3, "xiangbi", 1},
    {4, "jieqiao", 1}
};

ClassificationDetectionItem imgclassMobileNetV2ItemList[5] = {
    {0, "chunxiang", 1},
    {1, "minge", 1},
    {2, "changtiao", 1},
    {3, "xiangbi", 1},
    {4, "jieqiao", 1},
};

const int imgclassItemCount = sizeof(imgclassItemList) / sizeof(imgclassItemList[0]);
const int imgclassMobileNetV2ItemCount = sizeof(imgclassMobileNetV2ItemList) / sizeof(imgclassMobileNetV2ItemList[0]);

#endif
