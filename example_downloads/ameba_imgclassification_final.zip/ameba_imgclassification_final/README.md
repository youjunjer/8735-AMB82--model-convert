# AMB82-mini Image Classification Final

This folder is an independent copy of the final Arduino sketch variant used in this thread.

## Files

- `ameba_imgclassification_final.ino`
- `ClassificationClassList.h`
- `model/imgclassification.nb`

## Model assumptions

- Model type: `CUSTOMIZED_IMGCLASS`
- Model source: SD card
- Input size: `224x224`
- Input color: `RGB`
- Class list:
  - `0 chunxiang`
  - `1 minge`
  - `2 changtiao`
  - `3 xiangbi`
  - `4 jieqiao`

## SD card layout

Copy the model file to the SD card as:

`NN_MDL/imgclassification.nb`

The exported model included here is:

`model/imgclassification.nb`

## Upload parameters

Last successful upload used:

`ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd`

Example upload command:

```powershell
arduino-cli upload -p COM11 --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```

Example compile command:

```powershell
arduino-cli compile --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```
