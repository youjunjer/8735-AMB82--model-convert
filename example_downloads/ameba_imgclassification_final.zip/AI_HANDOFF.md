# AI Handoff

## Goal

This folder contains the final standalone Arduino sketch variant prepared during this thread for an AMB82-mini / Ameba Pro2 image classification test using a custom exported `.nb` model from SD card.

The current state is:

- Sketch compiles successfully.
- Model is loaded from SD card.
- Board was uploaded successfully before with the parameters recorded below.
- Runtime classification on device is suspicious: different camera inputs tend to produce nearly the same score distribution.

This document is intended for another AI to continue from the current state without needing the original thread.

## Final project folder

Project root:

`E:\codex\ameba_imgclassification_final`

Key files:

- `E:\codex\ameba_imgclassification_final\ameba_imgclassification_final.ino`
- `E:\codex\ameba_imgclassification_final\ClassificationClassList.h`
- `E:\codex\ameba_imgclassification_final\model\imgclassification.nb`
- `E:\codex\ameba_imgclassification_final\README.md`

## Board / upload parameters

Last successful board profile and options:

`ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd`

Example compile command:

```powershell
arduino-cli compile --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```

Example upload command:

```powershell
arduino-cli upload -p COM11 --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```

## Model assumptions

- Model type: `CUSTOMIZED_IMGCLASS`
- Model format: exported `.nb`
- Model file expected by Ameba runtime:
  - `NN_MDL/imgclassification.nb` on SD card
- Input size: `224x224`
- Input color mode currently set in sketch: `RGB`
- Model category count: `5`

## Class mapping used in sketch

The sketch currently uses:

- `0 chunxiang`
- `1 minge`
- `2 changtiao`
- `3 xiangbi`
- `4 jieqiao`

These are defined in:

`E:\codex\ameba_imgclassification_final\ClassificationClassList.h`

Note:

- The header now keeps only one class array:
  - `imgclassItemList`
- The unused MobileNetV2 class list and callback path were removed to keep the example single-path and easier to maintain.

## Current sketch behavior

The sketch:

- connects to Wi-Fi using the placeholder values in the sketch:
  - SSID: `YOUR_WIFI_SSID`
  - password: `YOUR_WIFI_PASSWORD`
- starts RTSP
- prints RTSP URL and model information to Serial
- runs custom image classification callback
- prints full class scores according to `SERIAL_PRINT_EVERY_N_INFERENCES`
- overlays top-1 class on OSD according to `OSD_UPDATE_EVERY_N_INFERENCES`

Relevant configuration in the sketch:

- `USE_MODEL_META_DATA_EN 0`
- `IMAGERGB 1`
- `NNWIDTH 224`
- `NNHEIGHT 224`
- `SERIAL_PRINT_EVERY_N_INFERENCES 1`
- `OSD_UPDATE_EVERY_N_INFERENCES 1`
- `imgclass.setResultCallback(ICPostProcess);`
- `imgclass.modelSelect(..., CUSTOMIZED_IMGCLASS);`

## Important finding: Arduino package example was modified later

During the thread, the original Arduino package example under:

`C:\Users\youadmin\AppData\Local\Arduino15\packages\ideasHatch\hardware\AmebaPro2\4.1.1-Release\libraries\NeuralNetwork\examples\RTSPImageClassification`

was no longer consistent with the version used earlier in the thread. At inspection time it had different class labels (`BG/PP/RK/SS` etc.).

To avoid ambiguity, the standalone folder in `E:\codex\ameba_imgclassification_final` should be treated as the authoritative final thread artifact.

## Model conversion artifacts found in workspace

Relevant conversion / verification folders found:

- `E:\codex\nb_workspace`
- `E:\codex\nb_build`
- `E:\codex\verify_infer`
- `E:\codex\converted_keras_unzip`
- `E:\codex\tm_current_unzip`

Important files:

- `E:\codex\nb_workspace\build_nbg_unify\network_binary.nb`
- `E:\codex\nb_build\inputmeta_teachable.yml`
- `E:\codex\verify_infer\compare_results.json`
- `E:\codex\verify_infer\keras_results.json`
- `E:\codex\converted_keras_unzip\keras_model.h5`
- `E:\codex\converted_keras_unzip\labels.txt`

The standalone project model file was copied from:

`E:\codex\nb_workspace\build_nbg_unify\network_binary.nb`

to:

`E:\codex\ameba_imgclassification_final\model\imgclassification.nb`

## Verification result from offline conversion

The strongest evidence from the workspace is:

`E:\codex\verify_infer\compare_results.json`

This file shows:

- Keras original model and Acuity-converted model matched on the verification set.
- Top-1 results were consistent across all 10 checked images.
- Confidence was generally high.

This means:

- the offline conversion pipeline is not obviously broken
- the device runtime issue is more likely related to deployment/runtime input handling than to basic model export failure

## Input preprocessing used during conversion

From:

`E:\codex\nb_build\inputmeta_teachable.yml`

the conversion used preprocessing equivalent to:

```text
(pixel - 127.5) * 0.007874015748031496
```

which is the standard:

```text
pixel / 127.5 - 1.0
```

Also:

- `preproc_type: IMAGE_RGB`
- layout in input meta: `nhwc`

From:

`E:\codex\nb_workspace\build_nbg_unify\nbg_meta.json`

the exported model input is quantized and reported with:

- input name: `input_105`
- shape: `[1, 224, 224, 3]`
- format: `nchw`
- qtype: `u8`
- scale: about `0.0078740157`
- zero point: `128`

This discrepancy between the conversion metadata and runtime behavior is one of the main things worth examining.

## On-device runtime symptom

Observed Serial output on device, regardless of different images, was approximately:

```text
class:jieqiao id:4 score:55-56
class:minge id:1 score:33-34
class:changtiao id:2 score:5
class:chunxiang id:0 score:2-3
class:xiangbi id:3 score:1
```

This was reported as staying effectively unchanged even when different images were used.

Interpretation:

- the class mapping is not the main problem
- the model output itself is nearly fixed on device
- likely causes are:
  - runtime preprocessing mismatch
  - camera-to-NN input path mismatch
  - channel/layout mismatch
  - board-side handling not matching the verified offline Acuity path

## Relevant source-level findings

From the installed Arduino package sources:

- `NNImageClassification.cpp` documents `configInputImageColor(int color)` as:
  - `1: RGB`
  - `0: BW`

This was one reason `IMAGERGB` was set to `1`.

At another stage earlier in the thread, `IMAGERGB` had been `0`. The final standalone project keeps it at `1`.

## What has already been validated

- Arduino CLI is installed and usable.
- Ameba Pro2 core is installed.
- Standalone project compiles successfully.
- Upload path with the recorded FQBN worked previously.
- SD model load option is explicitly selected through board parameter:
  - `06_LoadNNModelSource=sd`

## What has not been resolved

- Why device runtime outputs remain nearly constant across different visual inputs.
- Whether board camera frames actually vary at the tensor input seen by the NN runtime.
- Whether Arduino runtime preprocessing matches the offline verified Acuity preprocessing path.

## Suggested next steps for another AI

1. Treat `E:\codex\ameba_imgclassification_final` as the canonical current project.
2. Do not rely on the Arduino package example folder as authoritative.
3. Compare Ameba runtime preprocessing against:
   - `E:\codex\nb_build\inputmeta_teachable.yml`
   - `E:\codex\nb_workspace\build\vnn_pre_process.c`
4. Determine whether the board runtime path is effectively applying:
   - RGB order
   - resize to 224x224
   - `(x - 127.5) / 127.5`
5. If needed, test alternate runtime assumptions:
   - `IMAGERGB 0`
   - different callback instrumentation
   - explicit validation of camera frame variability
6. Verify whether the specific exported `.nb` used on SD is exactly the one compared in `compare_results.json`.
