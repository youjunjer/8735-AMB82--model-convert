# AMB82-mini Image Classification Final

This folder is an independent copy of the final Arduino sketch variant used in this thread.

## Files

- `RTSPImageClassification.ino`
- `ClassificationClassList.h`

## Model assumptions

- Model type: `CUSTOMIZED_IMGCLASS`
- Model source: SD card
- Input size: `224x224`
- Input color: `RGB`
- Class list:
  - `0 chunxiang`
  - `1 minge`
  - `2 changtiao`
  - `3 xiangbi`
  - `4 jieqiao`

## SD card layout

Copy your converted model file to the SD card as:

`NN_MDL/imgclassification.nb`

Note:

- The example zip does **not** include `imgclassification.nb`
- You need to place your own converted model on the SD card

## Wi-Fi setup

This example currently uses:

- `char ssid[] = "You2F";`
- `char pass[] = "0933932774";`

Edit them in `RTSPImageClassification.ino` if you need different Wi-Fi credentials.

## Upload parameters

Last successful upload used:

`ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd`

Example upload command:

```powershell
arduino-cli upload -p COM11 --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```

Example compile command:

```powershell
arduino-cli compile --fqbn "ideasHatch:AmebaPro2:Ameba_HUB-8735_ultra:01_AutoUploadMode=Enable,02_UploadBaudrate=1M,06_LoadNNModelSource=sd" "E:\codex\ameba_imgclassification_final"
```
