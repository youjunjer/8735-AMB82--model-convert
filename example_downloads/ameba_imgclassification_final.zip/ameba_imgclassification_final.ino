/*
  Standalone sketch copied from the working RTSP image classification setup.
  Model source: SD card / NN_MDL/imgclassification.nb
  Model type: Sequential CNN (CUSTOMIZED_IMGCLASS)
*/

#include "WiFi.h"
#include "StreamIO.h"
#include "VideoStream.h"
#include "RTSP.h"
#include "NNImageClassification.h"
#include "VideoStreamOverlay.h"
#include "ClassificationClassList.h"

#define USE_MODEL_META_DATA_EN 0

// 1: RGB, 0: BW
#define IMAGERGB 1

#define CHANNEL   0
#define CHANNELNN 3

#define NNWIDTH  224
#define NNHEIGHT 224

VideoSetting config(VIDEO_FHD, 30, VIDEO_H264, 0);
VideoSetting configNN(NNWIDTH, NNHEIGHT, 10, VIDEO_RGB, 0);
NNImageClassification imgclass;
RTSP rtsp;
StreamIO videoStreamer(1, 1);
StreamIO videoStreamerNN(1, 1);

char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD";
int status = WL_IDLE_STATUS;

IPAddress ip;
int rtsp_portnum;

void ICPostProcess_MobileNetV2(std::vector<ImageClassificationResult> results);
void ICPostProcess(std::vector<ImageClassificationResult> results);

void setup()
{
    Serial.begin(115200);

    while (status != WL_CONNECTED) {
        Serial.print("Attempting to connect to WPA SSID: ");
        Serial.println(ssid);
        status = WiFi.begin(ssid, pass);
        delay(2000);
    }
    ip = WiFi.localIP();

    config.setBitrate(2 * 1024 * 1024);
    Camera.configVideoChannel(CHANNEL, config);
    Camera.configVideoChannel(CHANNELNN, configNN);
    Camera.videoInit();

    rtsp.configVideo(config);
    rtsp.begin();
    rtsp_portnum = rtsp.getPort();
    Serial.print("RTSP URL: rtsp://");
    Serial.print(ip);
    Serial.print(":");
    Serial.println(rtsp_portnum);
    Serial.println("NN model source: SD card / NN_MDL/imgclassification.nb");
    Serial.println("Image classification model: CUSTOMIZED_IMGCLASS / Sequential CNN");
    Serial.print("NN input size: ");
    Serial.print(NNWIDTH);
    Serial.print("x");
    Serial.println(NNHEIGHT);
    Serial.print("Input image color: ");
    Serial.println(IMAGERGB ? "RGB" : "BW");

    imgclass.configVideo(configNN);
    imgclass.configInputImageColor(IMAGERGB);
    imgclass.useModelMetaData(USE_MODEL_META_DATA_EN);
    imgclass.setResultCallback(ICPostProcess);
    imgclass.modelSelect(IMAGE_CLASSIFICATION, NA_MODEL, NA_MODEL, NA_MODEL, NA_MODEL, CUSTOMIZED_IMGCLASS);
    imgclass.begin();

    videoStreamer.registerInput(Camera.getStream(CHANNEL));
    videoStreamer.registerOutput(rtsp);
    if (videoStreamer.begin() != 0) {
        Serial.println("StreamIO link start failed");
    }
    Camera.channelBegin(CHANNEL);

    videoStreamerNN.registerInput(Camera.getStream(CHANNELNN));
    videoStreamerNN.setStackSize();
    videoStreamerNN.setTaskPriority();
    videoStreamerNN.registerOutput(imgclass);
    if (videoStreamerNN.begin() != 0) {
        Serial.println("StreamIO link start failed");
    }
    Camera.channelBegin(CHANNELNN);

    OSD.configVideo(CHANNEL, config);
    OSD.begin();
}

void loop()
{
}

void ICPostProcess_MobileNetV2(std::vector<ImageClassificationResult> results)
{
    OSD.createBitmap(CHANNEL);
    for (int i = 0; i < imgclass.getResultCount(); i++) {
        ImageClassificationResult imgclass_item = results[i];
        int class_id = (int)imgclass_item.classID();
        int prob = 0;
        if ((class_id >= 0) && (class_id < imgclassMobileNetV2ItemCount) && imgclassMobileNetV2ItemList[class_id].filter) {
            char text_str[40];
            prob = imgclass_item.score();
            if (USE_MODEL_META_DATA_EN) {
                snprintf(text_str, sizeof(text_str), "class:%s %d", imgclass.getClassNameFromMeta(imgclass.model_meta_data, class_id, prob), prob);
            } else {
                snprintf(text_str, sizeof(text_str), "class:%s %d", imgclassMobileNetV2ItemList[class_id].imgclassName, imgclass_item.score());
                printf("class:%s %d\r\n", imgclassMobileNetV2ItemList[class_id].imgclassName, imgclass_item.score());
            }
            OSD.drawText(CHANNEL, 20, 20, text_str, OSD_COLOR_CYAN);
        }
    }
    OSD.update(CHANNEL);
}

void ICPostProcess(std::vector<ImageClassificationResult> results)
{
    static uint32_t inference_count = 0;
    inference_count++;

    if (imgclass.getResultCount() > 0) {
        if ((inference_count % 10) != 1) {
            return;
        }

        printf("---- class scores #%lu ----\r\n", inference_count);
        for (int i = 0; i < imgclass.getResultCount(); i++) {
            ImageClassificationResult imgclass_item = results[i];
            int class_id = (int)imgclass_item.classID();
            if ((class_id >= 0) && (class_id < imgclassItemCount) && imgclassItemList[class_id].filter) {
                printf("class:%s id:%d score:%d\r\n", imgclassItemList[class_id].imgclassName, class_id, imgclass_item.score());
            } else {
                printf("class:unknown id:%d score:%d\r\n", class_id, imgclass_item.score());
            }
        }

        OSD.createBitmap(CHANNEL);
        char text_str[40];
        ImageClassificationResult top_imgclass_item = results[0];
        int top_class_id = (int)top_imgclass_item.classID();
        if ((top_class_id >= 0) && (top_class_id < imgclassItemCount) && imgclassItemList[top_class_id].filter) {
            snprintf(text_str, sizeof(text_str), "class:%s %d", imgclassItemList[top_class_id].imgclassName, top_imgclass_item.score());
            printf("top class detected: %s %d\r\n", imgclassItemList[top_class_id].imgclassName, top_imgclass_item.score());
        } else {
            snprintf(text_str, sizeof(text_str), "class:unknown %d", top_imgclass_item.score());
            printf("top class detected: unknown id:%d score:%d\r\n", top_class_id, top_imgclass_item.score());
        }
        OSD.drawText(CHANNEL, 20, 20, text_str, OSD_COLOR_CYAN);
        OSD.update(CHANNEL);
    }
}
